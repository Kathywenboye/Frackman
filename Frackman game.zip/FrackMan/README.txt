To run FrackMan:

1. Locate the folder FrackMan, which should have in it files named
FrackMan and Assets.  It's likely that the path to the folder will be
/Users/yourname/FrackMan or /Users/yourname/Downloads/FrackMan.

2. Open a Terminal window and type
	cd whateverThePathIs
where you should replace whateverThePathIs with the path to the FrackMan
folder.

3. Confirm you're in the right folder by typing
	ls
which should show you the Assets folder and the FrackMan executable.

4. Type
	./FrackMan
to play the game.  Use the arrow keys to move the space bar to squirt, and
the space bar to drop a gold nugget.  You can type q to quit the game
prematurely.

Alternatively, in the folder FrackMan, you can move the Assets folder
to your home directory, then double-click on the FrackMan executable
file.
